import java.util.ArrayList;

public interface AlgoInterface {
	public ArrayList<Integer> handle(ArrayList<Integer> numbers);
}
